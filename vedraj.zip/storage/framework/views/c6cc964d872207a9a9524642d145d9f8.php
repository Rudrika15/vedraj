

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="d-flex justify-content-between mb-3">
            <div class="">
                <h3>Products</h3>
            </div>
            <div class="">
                <a href="<?php echo e(route('product.create', request()->id)); ?>" class="btn btn-primary">Add Product</a>
            </div>
        </div>
        <div class="table table-responsive">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>#</th>
                        <th scope="col"> Disease Name </th>
                        <th scope="col">Product Name</th>
                        <th scope="col">Product Description</th>
                        <th scope="col">Amazon Link</th>
                        <th scope="col">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"><?php echo e($loop->iteration); ?></th>
                            <td><?php echo e($product->disease->disease_name); ?></td>
                            <td><?php echo e($product->product_name); ?></td>
                            <td><?php echo e($product->description); ?></td>
                            <td><?php echo e($product->amazon_link); ?></td>
                            <td>
                                <div class="d-flex gap-2">
                                    <a href="<?php echo e(route('product.edit', $product->id)); ?>" class="btn btn-xs btn-primary">
                                        Edit
                                    </a>
                                    <a href="<?php echo e(route('product.delete', $product->id)); ?>"
                                        data-url="<?php echo e(route('product.delete', $product->id)); ?>"
                                        class="btn btn-xs btn-danger delete-button">
                                        Delete
                                    </a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Flipcode\Laravel\Vedraj\vedraj\resources\views/product/index.blade.php ENDPATH**/ ?>