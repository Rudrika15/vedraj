

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="d-flex justify-content-between mb-3">
            <div class="">
                <h3>Videos</h3>
            </div>
            <div class="">
                <a href="<?php echo e(route('video.create')); ?>" class="btn btn-primary">Create Video</a>
            </div>
        </div>

        <div class="table-responsive">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Disease Name</th>
                        <th scope="col">Title</th>
                        <th scope="col">Youtube Link</th>
                        <th scope="col">Image</th>
                        <th scope="col">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"><?php echo e($loop->iteration); ?></th>
                            <td><?php echo e($video->disease->disease_name); ?></td>
                            <td><?php echo e($video->title); ?></td>
                            <td><?php echo e($video->youtube_link); ?></td>
                            <td><img src="<?php echo e(asset('images/videos/' . $video->thumbnail)); ?>" width="120" alt="">
                            </td>
                            <td>
                                <div class="d-flex gap-2">
                                    <a href="<?php echo e(route('video.edit', $video->id)); ?>" class="btn btn-xs btn-primary">Edit</a>
                                    <a href="<?php echo e(route('video.delete', $video->id)); ?>"
                                        data-url="<?php echo e(route('video.delete', $video->id)); ?>"
                                        class="btn btn-xs btn-danger delete-button">Delete</a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Flipcode\Laravel\Vedraj\vedraj\resources\views/video/index.blade.php ENDPATH**/ ?>