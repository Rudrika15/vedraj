

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="d-flex justify-content-between mb-3">
            <div class="">
                <h3>Staff</h3>
            </div>
            <div class="margin-top-10">
                <a href="<?php echo e(route('staff.create')); ?>" class="btn btn-sm btn-primary">
                    Add Staff
                </a>
            </div>
        </div>

        <div class="table-responsive">
            <table class="table table-bordered ">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Name</th>
                        <th scope="col">Email</th>
                        <th scope="col">Mobile</th>
                        <th scope="col">Address</th>
                        <th scope="col">Branch</th>
                        <th scope="col">Role</th>
                        <th scope="col">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $staffs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $staff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"><?php echo e($loop->iteration); ?></th>
                            <td><?php echo e($staff->name); ?></td>
                            <td><?php echo e($staff->email); ?></td>
                            <td><?php echo e($staff->mobile_no); ?></td>
                            <td><?php echo e($staff->address); ?></td>
                            <td><?php echo e($staff->branch->branch_name ?? ''); ?></td>
                            <td><?php echo e($staff->role); ?></td>
                            <td class="d-flex gap-2">
                                <a href="<?php echo e(route('staff.edit', $staff->id)); ?>" class="btn btn-xs btn-primary">Edit</a>
                                <a href="<?php echo e(route('staff.delete', $staff->id)); ?>"
                                    data-url="<?php echo e(route('staff.delete', $staff->id)); ?>"
                                    class="btn btn-xs btn-danger delete-button">Delete</a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <div class="d-flex justify-content-end">
                <?php echo e($staffs->links()); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Flipcode\Laravel\Vedraj\vedraj\resources\views/staff/index.blade.php ENDPATH**/ ?>