

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="d-flex justify-content-between mb-3">
            <div class="">

                <h3>Disease</h3>
            </div>
            <div class="margin-top-10">
                <a href="<?php echo e(route('disease.create')); ?>" class="btn btn-sm btn-primary">
                    Add Disease
                </a>
            </div>
        </div>

        <div class="table-responsive">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Disease Name</th>
                        <th scope="col">Description</th>
                        <th scope="col">URL</th>
                        <th scope="col">Thumbnail</th>
                        <th scope="col">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $diseases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $disease): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"><?php echo e($loop->iteration); ?></th>
                            <td><?php echo e($disease->disease_name); ?></td>
                            <td><?php echo e($disease->description); ?></td>
                            <td><?php echo e($disease->url); ?></td>
                            <td><img src="<?php echo e(asset('images/diseases/' . $disease->thumbnail)); ?>" width="120"
                                    alt=""></td>
                            <td>
                                <div class="d-flex gap-2">

                                    <a href="<?php echo e(route('disease.edit', $disease->id)); ?>" class="btn btn-xs btn-primary">
                                        Edit
                                    </a>
                                    <a href="<?php echo e(route('disease.delete', $disease->id)); ?>"
                                        data-url="<?php echo e(route('disease.delete', $disease->id)); ?>"
                                        class="btn btn-xs btn-danger delete-button">
                                        Delete
                                    </a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <div class="d-flex justify-content-end">
                <?php echo e($diseases->links()); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Flipcode\Laravel\Vedraj\vedraj\resources\views/disease/index.blade.php ENDPATH**/ ?>