

<?php $__env->startSection('content'); ?>
    <div class="container mb-3">
        <div class="d-flex justify-content-between mb-3">
            <div class="">
                <h3>Edit Branch</h3>
            </div>
            <div class="">
                <a href="<?php echo e(route('branch.index')); ?>" class="btn btn-primary">Back</a>
            </div>
        </div>
        <form method="POST" action="<?php echo e(route('branch.update', $branch->id)); ?>">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="name">Name</label>
                <input type="text" class="form-control" id="name" name="branch_name"
                    value="<?php echo e($branch->branch_name); ?>">
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group">
                <label for="pincode">Pincode</label>
                <input type="number" class="form-control" id="pincode" name="pincode" value="<?php echo e($branch->pincode); ?>">
            </div>
            <div class="form-group">
                <label for="city">City</label>
                <input type="text" class="form-control" id="city" name="city" value="<?php echo e($branch->city); ?>">
            </div>
            <div class="form-group">
                <label for="mobile_no">Mobile No</label>
                <input type="number" class="form-control" id="mobile_no" name="mobile_no" value="<?php echo e($branch->mobile_no); ?>">
            </div>
            <button type="submit" class="btn btn-primary">Update</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Flipcode\Laravel\Vedraj\vedraj\resources\views/branch/edit.blade.php ENDPATH**/ ?>