

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Dashboard</h1>
        <p>Welcome to your dashboard</p>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Flipcode\Laravel\Vedraj\vedraj\resources\views/dashboard.blade.php ENDPATH**/ ?>