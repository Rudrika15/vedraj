

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="d-flex justify-content-between mb-3">
            <div class="">

                <h3>Articles</h3>
            </div>
            <div class="">
                <a href="<?php echo e(route('article.create')); ?>" class="btn btn-primary">Add Article</a>
            </div>
        </div>

        <div class="table-responsive">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>#</th>
                        <th scope="col">Disease Name</th>
                        <th scope="col">Article Name</th>
                        <th scope="col">Article Image</th>
                        <th scope="col">URL</th>
                        <th scope="col">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"><?php echo e($loop->iteration); ?></th>
                            <td><?php echo e($article->disease->disease_name); ?></td>
                            <td><?php echo e($article->title); ?></td>
                            <td>
                                <img src="<?php echo e(asset('images/articles/' . $article->thumbnail)); ?>" width="120"
                                    alt="">
                            </td>
                            <td><?php echo e($article->url); ?></td>
                            <td>
                                <div class="d-flex gap-2">

                                    <a href="<?php echo e(route('article.edit', $article->id)); ?>" class="btn btn-xs btn-primary">
                                        Edit
                                    </a>
                                    <a href="<?php echo e(route('article.delete', $article->id)); ?>"
                                        data-url="<?php echo e(route('article.delete', $article->id)); ?>"
                                        class="btn btn-xs btn-danger delete-button">
                                        Delete
                                    </a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Flipcode\Laravel\Vedraj\vedraj\resources\views/article/index.blade.php ENDPATH**/ ?>