 <footer class="footer" style="bottom: 0; display: block; width: 100%;">
     <ul class="list-inline">
         <li>2024 © vedraj.</li>
         <li><a href="#">Privacy</a></li>
         <li><a href="#">Terms</a></li>
         <li><a href="#">Help</a></li>
     </ul>
 </footer>
<?php /**PATH C:\Flipcode\Laravel\Vedraj\vedraj\resources\views/layouts/footer.blade.php ENDPATH**/ ?>