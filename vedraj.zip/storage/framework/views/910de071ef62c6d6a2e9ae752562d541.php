

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="d-flex justify-content-between mb-3">
            <div class="">
                <h3>Branches</h3>
            </div>
            <div>
                <a href="<?php echo e(route('branch.create')); ?>" class="btn btn-sm btn-primary ">
                    Create Branch
                </a>
            </div>
        </div>
        <div class=" table-responsive">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Branch Name</th>
                        <th scope="col">Branch PinCode</th>
                        <th scope="col">Branch City</th>
                        <th scope="col">Branch Mobile</th>
                        <th scope="col">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($branch->branch_name); ?></td>
                            <td><?php echo e($branch->pincode); ?></td>
                            <td><?php echo e($branch->city); ?></td>
                            <td><?php echo e($branch->mobile_no); ?></td>
                            <td class="d-flex gap-2">
                                <a href="<?php echo e(route('branch.edit', $branch->id)); ?>" class="btn btn-xs btn-primary">Edit</a>
                                <a href="<?php echo e(route('branch.delete', $branch->id)); ?>"
                                    data-url="<?php echo e(route('branch.delete', $branch->id)); ?>"
                                    class="btn btn-xs btn-danger delete-button">Delete</a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <div class="d-flex justify-content-end">
                <?php echo e($branches->links()); ?>

            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Flipcode\Laravel\Vedraj\vedraj\resources\views/branch/index.blade.php ENDPATH**/ ?>